import express from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket as WSWebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

import { db } from './backend/database.js';
import { binanceStream, setUIBroadcaster } from './backend/agents.js';

dotenv.config();

const isProduction = process.env.NODE_ENV === 'production';
const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json());

  const server = http.createServer(app);

  // Set up WebSocket server for UI Dashboard clients
  const wss = new WebSocketServer({ noServer: true });

  // Map of active UI connections
  const connectedUIWebsockets = new Set<WSWebSocket>();

  wss.on('connection', (ws: WSWebSocket) => {
    connectedUIWebsockets.add(ws);
    console.log(`UI Client connected to security stream feed. Total: ${connectedUIWebsockets.size}`);

    // Immediately send the stream connection status, current database state
    ws.send(JSON.stringify({
      type: 'stream_status',
      data: { status: binanceStream.getStatus() }
    }));

    ws.send(JSON.stringify({
      type: 'init_state',
      data: {
        recentAlerts: db.getAlerts(30),
        recentTransactions: db.getTransactions(50),
        anomalyScores: db.getAnomalyScores(100),
        agentLogs: db.getAgentLogs(50)
      }
    }));

    ws.on('close', () => {
      connectedUIWebsockets.delete(ws);
      console.log(`UI Client disconnected. Connected: ${connectedUIWebsockets.size}`);
    });

    ws.on('error', (err) => {
      console.error('UI WS client encountered error:', err);
      connectedUIWebsockets.delete(ws);
    });
  });

  // Handle incoming HTTP connection upgrades to WS protocol for '/ws/live-alerts'
  server.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url || '', `http://${request.headers.host}`).pathname;

    if (pathname === '/ws/live-alerts') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  // Provide the multi-agent framework with a broadcaster reference to UI clients
  setUIBroadcaster((type: string, data: any) => {
    const packet = JSON.stringify({ type, data });
    connectedUIWebsockets.forEach((client) => {
      if (client.readyState === WSWebSocket.OPEN) {
        client.send(packet);
      }
    });
  });

  // REST API Endpoints for UI
  app.get('/api/status', (req, res) => {
    const recentAlerts = db.getAlerts(100);
    const criticalCount = recentAlerts.filter(a => a.riskLevel === 'CRITICAL').length;
    const highCount = recentAlerts.filter(a => a.riskLevel === 'HIGH').length;

    res.json({
      status: 'operational',
      binanceFeed: binanceStream.getStatus(),
      activeAgentsCount: 6,
      threatLevel: criticalCount > 0 ? 'CRITICAL' : (highCount > 0 ? 'HIGH' : 'LOW'),
      connectedUIs: connectedUIWebsockets.size,
      uptime: process.uptime()
    });
  });

  app.get('/api/alerts', (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    res.json(db.getAlerts(limit));
  });

  app.get('/api/latest', (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
    res.json(db.getTransactions(limit));
  });

  app.get('/api/agents/status', (req, res) => {
    res.json({
      agents: [
        { name: 'DataAgent', role: 'Ingest & Normalize', status: binanceStream.getStatus() === 'connected' ? 'active' : 'idle', details: 'Listening to BTCUSDT, ETHUSDT, SOLUSDT Binance Streams' },
        { name: 'FeatureAgent', role: 'Statistical Multi-Feature Generation', status: 'active', details: 'Analyzing sliding variance and volatility arrays' },
        { name: 'MLAgent', role: 'Isolation Forest Anomaly Assessment', status: 'active', details: 'Classifying threat probability indices from multi-feature vectors' },
        { name: 'GeminiAgent', role: 'Cognitive Context Explanation', status: process.env.GEMINI_API_KEY ? 'active' : 'restricted', details: 'Generating structural 1-2 sentence threat analyses via Gemini-3.5-flash' },
        { name: 'ValidatorAgent', role: 'Rigid Verification filter', status: 'active', details: 'Compiling dynamic validation vectors and false-alarm coefficients' },
        { name: 'AlertAgent', role: 'Global UI Dispatch Router', status: 'active', details: 'Streaming security packets directly down UI clients socket' }
      ],
      logs: db.getAgentLogs(100)
    });
  });

  app.post('/api/system/reset', (req, res) => {
    db.resetDatabase();
    res.json({ status: 'success', message: 'Intelligence databases cleared and seeded with clean states.' });
  });

  // Vite static file server or bundling configurations
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Connect to Binance live trade WS stream directly at start
  binanceStream.connect();

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Cryptocurrency Fraud Engine running on port ${PORT}`);
  });
}

startServer();
