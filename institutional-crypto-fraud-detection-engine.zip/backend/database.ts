import fs from 'fs';
import path from 'path';

export interface Transaction {
  id: string;
  symbol: string;
  price: number;
  quantity: number;
  valueUsd: number;
  timestamp: number;
  walletAddress: string;
  isAnomaly: boolean;
  anomalyScore: number;
}

export interface Alert {
  id: string;
  timestamp: number;
  symbol: string;
  price: number;
  quantity: number;
  valueUsd: number;
  anomalyScore: number;
  fraudProbability: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  reasoning: string;
  validatorConfidence: number;
  falsePositiveProb: number;
  walletAddress: string;
}

export interface AgentLog {
  id: string;
  timestamp: number;
  agentName: 'DataAgent' | 'FeatureAgent' | 'MLAgent' | 'GeminiAgent' | 'ValidatorAgent' | 'AlertAgent';
  type: 'info' | 'warning' | 'alert' | 'success';
  message: string;
}

export interface AnomalyScoreRecord {
  timestamp: number;
  symbol: string;
  score: number;
  price: number;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

class EmulatedDatabase {
  private state: {
    transactions: Transaction[];
    alerts: Alert[];
    agent_logs: AgentLog[];
    anomaly_scores: AnomalyScoreRecord[];
  } = {
    transactions: [],
    alerts: [],
    agent_logs: [],
    anomaly_scores: []
  };

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.state = JSON.parse(raw);
        console.log(`Database loaded successfully with ${this.state.alerts.length} alerts.`);
      } else {
        this.seed();
        this.save();
      }
    } catch (err) {
      console.error('Failed to initialize database, resetting to empty', err);
      this.state = { transactions: [], alerts: [], agent_logs: [], anomaly_scores: [] };
    }
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.state, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save emulated database file', err);
    }
  }

  // Seeding realistic initial institutional datasets
  private seed() {
    console.log('Seeding initial cybersecurity crypto threat intelligence...');
    
    // Seed some suspect wallet addresses
    const wallets = [
      '0xef8c54ff1a0525164d1cd9a2be7ebcdb397bf0d5', // Flagged mixer receiver
      '0x9c3d4a64ca1cd1d4ad0ad7be3f97ca195ce6368d', // Sybil attacker
      '0x3c2ecdd9eefa6324dcd9a5beee9bfbfe397bc0d7', // Flashloan exploiter
    ];

    const symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT'];

    // 1. Logs
    this.state.agent_logs = [
      {
        id: 'log_1',
        timestamp: Date.now() - 3600000,
        agentName: 'DataAgent',
        type: 'info',
        message: 'Established WebSocket connection to Binance Live Feed for BTCUSDT, ETHUSDT, SOLUSDT.'
      },
      {
        id: 'log_2',
        timestamp: Date.now() - 3550000,
        agentName: 'FeatureAgent',
        type: 'info',
        message: 'Feature Pipeline initialized. Monitoring volatility bands, volume multipliers, and address clustering.'
      },
      {
        id: 'log_3',
        timestamp: Date.now() - 3500000,
        agentName: 'MLAgent',
        type: 'success',
        message: 'Isolation Forest Pipeline successfully loaded. Z-Score dynamic thresholds synced.'
      },
      {
        id: 'log_4',
        timestamp: Date.now() - 3400000,
        agentName: 'GeminiAgent',
        type: 'info',
        message: 'Gemini-3.5-flash reasoning client warm-up OK. Ready for real-time natural language threat analysis.'
      },
      {
        id: 'log_5',
        timestamp: Date.now() - 3350000,
        agentName: 'ValidatorAgent',
        type: 'info',
        message: 'Claude validation filter synchronized. Estimating false positive triggers.'
      },
      {
        id: 'log_6',
        timestamp: Date.now() - 3300000,
        agentName: 'AlertAgent',
        type: 'success',
        message: 'Security Alerts Dispatch routing websocket active.'
      }
    ];

    // 2. Anomaly Scores Trends over last 20 frames
    const now = Date.now();
    for (let i = 20; i >= 0; i--) {
      this.state.anomaly_scores.push({
        timestamp: now - i * 60000,
        symbol: 'BTCUSDT',
        score: Math.max(12, Math.floor(15 + Math.sin(i * 0.5) * 8 + (i % 7 === 0 ? 30 : 0))),
        price: 68320 + Math.sin(i) * 150
      }, {
        timestamp: now - i * 60000,
        symbol: 'ETHUSDT',
        score: Math.max(8, Math.floor(10 + Math.cos(i * 0.5) * 11 + (i % 6 === 0 ? 25 : 0))),
        price: 3450 + Math.cos(i) * 15
      }, {
        timestamp: now - i * 60000,
        symbol: 'SOLUSDT',
        score: Math.max(5, Math.floor(18 + Math.sin(i * 0.8) * 15 + (i % 5 === 0 ? 40 : 0))),
        price: 182.4 + Math.sin(i * 2) * 2.1
      });
    }

    // 3. Historical Alerts
    this.state.alerts = [
      {
        id: 'alert_t1',
        timestamp: now - 1800000,
        symbol: 'BTCUSDT',
        price: 68150.2,
        quantity: 18.5,
        valueUsd: 1260778,
         anomalyScore: 84,
        fraudProbability: 0.81,
        riskLevel: 'HIGH',
        reasoning: 'Massive single-block trade detected matching coordinated wallet exit behavior. Transaction amount represents an extreme 12x spike above the 5-minute local moving volume standard deviation. Address belongs to flagged high-risk mixer gateway.',
        validatorConfidence: 0.94,
        falsePositiveProb: 0.04,
        walletAddress: wallets[0]
      },
      {
        id: 'alert_t2',
        timestamp: now - 900000,
        symbol: 'ETHUSDT',
        price: 3415.8,
        quantity: 450.0,
        valueUsd: 1537110,
        anomalyScore: 92,
        fraudProbability: 0.94,
        riskLevel: 'CRITICAL',
        reasoning: 'Critical volatility deviation! Instantaneous price dropped by -3.2% while transaction throughput surged 890%. Address identified as a participant in a series of circular wash trading clusters mimicking liquidity pooling exploit.',
        validatorConfidence: 0.97,
        falsePositiveProb: 0.01,
         walletAddress: wallets[2]
      }
    ];

    // 4. Default Transactions seed
    for (let i = 10; i >= 0; i--) {
      this.state.transactions.push({
        id: `tx_seed_${i}`,
        symbol: symbols[i % symbols.length],
        price: i % 3 === 0 ? 68150 : (i % 3 === 1 ? 3420 : 180),
        quantity: FloatValue(1 + (i * 0.15)),
        valueUsd: FloatValue((i % 3 === 0 ? 68150 : (i % 3 === 1 ? 3420 : 180)) * (1 + (i * 0.15))),
        timestamp: now - i * 120000,
        walletAddress: generateRandomAddress(),
        isAnomaly: i % 5 === 0,
        anomalyScore: i % 5 === 0 ? 72 : 12
      });
    }
  }

  // Transactions
  getTransactions(limit = 100): Transaction[] {
    return this.state.transactions.slice(-limit).reverse();
  }

  insertTransaction(tx: Transaction) {
    this.state.transactions.push(tx);
    if (this.state.transactions.length > 200) {
      this.state.transactions.shift();
    }
    this.save();
  }

  // Alerts
  getAlerts(limit = 50): Alert[] {
    return this.state.alerts.slice(-limit).reverse();
  }

  insertAlert(alert: Alert) {
    this.state.alerts.push(alert);
    if (this.state.alerts.length > 100) {
      this.state.alerts.shift();
    }
    this.save();
  }

  // Logs
  getAgentLogs(limit = 150): AgentLog[] {
    return this.state.agent_logs.slice(-limit).reverse();
  }

  insertAgentLog(agentName: AgentLog['agentName'], type: AgentLog['type'], message: string) {
    const log: AgentLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: Date.now(),
      agentName,
      type,
      message
    };
    this.state.agent_logs.push(log);
    if (this.state.agent_logs.length > 250) {
      this.state.agent_logs.shift();
    }
    this.save();
  }

  // Anomaly Scores Trends
  getAnomalyScores(limit = 100): AnomalyScoreRecord[] {
    return this.state.anomaly_scores.slice(-limit);
  }

  insertAnomalyScore(record: AnomalyScoreRecord) {
    this.state.anomaly_scores.push(record);
    // Maintain a rolling window of recent scores for charting
    if (this.state.anomaly_scores.length > 300) {
      this.state.anomaly_scores.shift();
    }
    this.save();
  }

  // Clear or utility methods
  resetDatabase() {
    this.state = { transactions: [], alerts: [], agent_logs: [], anomaly_scores: [] };
    this.seed();
    this.save();
  }
}

function FloatValue(v: number): number {
  return parseFloat(v.toFixed(4));
}

export function generateRandomAddress(): string {
  const chars = '0123456789abcdef';
  let addr = '0x';
  for (let i = 0; i < 40; i++) {
    addr += chars[Math.floor(Math.random() * chars.length)];
  }
  return addr;
}

export const db = new EmulatedDatabase();
